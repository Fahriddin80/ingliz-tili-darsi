export interface Word {
  id: number
  english: string
  uzbek: string
  category: string
  pronunciation?: string // API dan kelishi mumkin
  emoji: string
}

export const wordsData: Word[] = [
  // Hayvonlar
  { id: 1, english: "Cat", uzbek: "Mushuk", category: "animals", emoji: "🐱" },
  { id: 2, english: "Dog", uzbek: "It", category: "animals", emoji: "🐶" },
  { id: 3, english: "Bird", uzbek: "Qush", category: "animals", emoji: "🐦" },
  { id: 4, english: "Fish", uzbek: "Baliq", category: "animals", emoji: "🐟" },
  { id: 5, english: "Rabbit", uzbek: "Quyon", category: "animals", emoji: "🐰" },
  { id: 6, english: "Lion", uzbek: "Sher", category: "animals", emoji: "🦁" },
  { id: 7, english: "Tiger", uzbek: "Yo'lbars", category: "animals", emoji: "🐯" },
  { id: 8, english: "Elephant", uzbek: "Fil", category: "animals", emoji: "🐘" },
  { id: 9, english: "Monkey", uzbek: "Maymun", category: "animals", emoji: "🐒" },
  { id: 10, english: "Bear", uzbek: "Ayiq", category: "animals", emoji: "🐻" },

  // Ranglar
  { id: 11, english: "Red", uzbek: "Qizil", category: "colors", emoji: "🔴" },
  { id: 12, english: "Blue", uzbek: "Ko'k", category: "colors", emoji: "🔵" },
  { id: 13, english: "Green", uzbek: "Yashil", category: "colors", emoji: "🟢" },
  { id: 14, english: "Yellow", uzbek: "Sariq", category: "colors", emoji: "🟡" },
  { id: 15, english: "Purple", uzbek: "Binafsha", category: "colors", emoji: "🟣" },
  { id: 16, english: "Black", uzbek: "Qora", category: "colors", emoji: "⚫" },
  { id: 17, english: "White", uzbek: "Oq", category: "colors", emoji: "⚪" },
  { id: 18, english: "Orange", uzbek: "To'q sariq", category: "colors", emoji: "🟠" },
  { id: 19, english: "Pink", uzbek: "Pushti", category: "colors", emoji: "🌸" },
  { id: 20, english: "Brown", uzbek: "Jigarrang", category: "colors", emoji: "🟤" },

  // Mevalar
  { id: 21, english: "Apple", uzbek: "Olma", category: "fruits", emoji: "🍎" },
  { id: 22, english: "Banana", uzbek: "Banan", category: "fruits", emoji: "🍌" },
  { id: 23, english: "Orange", uzbek: "Apelsin", category: "fruits", emoji: "🍊" },
  { id: 24, english: "Grape", uzbek: "Uzum", category: "fruits", emoji: "🍇" },
  { id: 25, english: "Strawberry", uzbek: "Qulupnay", category: "fruits", emoji: "🍓" },
  { id: 26, english: "Pineapple", uzbek: "Ananas", category: "fruits", emoji: "🍍" },
  { id: 27, english: "Mango", uzbek: "Mango", category: "fruits", emoji: "🥭" },
  { id: 28, english: "Watermelon", uzbek: "Tarvuz", category: "fruits", emoji: "🍉" },
  { id: 29, english: "Cherry", uzbek: "Gilos", category: "fruits", emoji: "🍒" },
  { id: 30, english: "Lemon", uzbek: "Limon", category: "fruits", emoji: "🍋" },

  // Raqamlar
  { id: 31, english: "One", uzbek: "Bir", category: "numbers", emoji: "1️⃣" },
  { id: 32, english: "Two", uzbek: "Ikki", category: "numbers", emoji: "2️⃣" },
  { id: 33, english: "Three", uzbek: "Uch", category: "numbers", emoji: "3️⃣" },
  { id: 34, english: "Four", uzbek: "To'rt", category: "numbers", emoji: "4️⃣" },
  { id: 35, english: "Five", uzbek: "Besh", category: "numbers", emoji: "5️⃣" },
  { id: 36, english: "Six", uzbek: "Olti", category: "numbers", emoji: "6️⃣" },
  { id: 37, english: "Seven", uzbek: "Yetti", category: "numbers", emoji: "7️⃣" },
  { id: 38, english: "Eight", uzbek: "Sakkiz", category: "numbers", emoji: "8️⃣" },
  { id: 39, english: "Nine", uzbek: "To'qqiz", category: "numbers", emoji: "9️⃣" },
  { id: 40, english: "Ten", uzbek: "O'n", category: "numbers", emoji: "🔟" },
  { id: 41, english: "Eleven", uzbek: "O'n bir", category: "numbers", emoji: "🔢" },
  { id: 42, english: "Twelve", uzbek: "O'n ikki", category: "numbers", emoji: "🔢" },
  { id: 43, english: "Thirteen", uzbek: "O'n uch", category: "numbers", emoji: "🔢" },
  { id: 44, english: "Fourteen", uzbek: "O'n to'rt", category: "numbers", emoji: "🔢" },
  { id: 45, english: "Fifteen", uzbek: "O'n besh", category: "numbers", emoji: "🔢" },
  { id: 46, english: "Twenty", uzbek: "Yigirma", category: "numbers", emoji: "🔢" },
  { id: 47, english: "Fifty", uzbek: "Ellik", category: "numbers", emoji: "🔢" },
  { id: 48, english: "Hundred", uzbek: "Yuz", category: "numbers", emoji: "💯" },
  { id: 49, english: "Thousand", uzbek: "Ming", category: "numbers", emoji: "🔢" },
  { id: 50, english: "Million", uzbek: "Million", category: "numbers", emoji: "🔢" },

  // Tana a'zolari
  { id: 51, english: "Head", uzbek: "Bosh", category: "body", emoji: "👤" },
  { id: 52, english: "Arm", uzbek: "Qo'l (yelkadan bilakkacha)", category: "body", emoji: "💪" },
  { id: 53, english: "Leg", uzbek: "Oyoq", category: "body", emoji: "🦵" },
  { id: 54, english: "Hand", uzbek: "Qo'l (panja)", category: "body", emoji: "✋" },
  { id: 55, english: "Foot", uzbek: "Oyoq (panja)", category: "body", emoji: "🦶" },
  { id: 56, english: "Eye", uzbek: "Ko'z", category: "body", emoji: "👁️" },
  { id: 57, english: "Ear", uzbek: "Quloq", category: "body", emoji: "👂" },
  { id: 58, english: "Nose", uzbek: "Burun", category: "body", emoji: "👃" },
  { id: 59, english: "Mouth", uzbek: "Og'iz", category: "body", emoji: "👄" },
  { id: 60, english: "Tooth", uzbek: "Tish", category: "body", emoji: "🦷" },

  // Kiyim-kechak
  { id: 61, english: "Shirt", uzbek: "Ko'ylak", category: "clothes", emoji: "👕" },
  { id: 62, english: "Pants", uzbek: "Shim", category: "clothes", emoji: "👖" },
  { id: 63, english: "Dress", uzbek: "Ko'ylak (ayollar)", category: "clothes", emoji: "👗" },
  { id: 64, english: "Shoes", uzbek: "Poyabzal", category: "clothes", emoji: "👟" },
  { id: 65, english: "Hat", uzbek: "Shlyapa", category: "clothes", emoji: "🎩" },

  // Taom
  { id: 66, english: "Bread", uzbek: "Non", category: "food", emoji: "🍞" },
  { id: 67, english: "Milk", uzbek: "Sut", category: "food", emoji: "🥛" },
  { id: 68, english: "Water", uzbek: "Suv", category: "food", emoji: "💧" },
  { id: 69, english: "Cheese", uzbek: "Pishloq", category: "food", emoji: "🧀" },
  { id: 70, english: "Egg", uzbek: "Tuxum", category: "food", emoji: "🥚" },

  // Uy-joy
  { id: 71, english: "House", uzbek: "Uy", category: "house", emoji: "🏠" },
  { id: 72, english: "Room", uzbek: "Xona", category: "house", emoji: "🚪" },
  { id: 73, english: "Bed", uzbek: "Krovat", category: "house", emoji: "🛏️" },
  { id: 74, english: "Table", uzbek: "Stol", category: "house", emoji: "🛋️" },
  { id: 75, english: "Chair", uzbek: "Stul", category: "house", emoji: "🪑" },

  // Transport
  { id: 76, english: "Car", uzbek: "Mashina", category: "transport", emoji: "🚗" },
  { id: 77, english: "Bus", uzbek: "Avtobus", category: "transport", emoji: "🚌" },
  { id: 78, english: "Train", uzbek: "Poyezd", category: "transport", emoji: "🚂" },
  { id: 79, english: "Bicycle", uzbek: "Velosiped", category: "transport", emoji: "🚲" },
  { id: 80, english: "Airplane", uzbek: "Samolyot", category: "transport", emoji: "✈️" },

  // Tabiat
  { id: 81, english: "Tree", uzbek: "Daraxt", category: "nature", emoji: "🌳" },
  { id: 82, english: "Flower", uzbek: "Gul", category: "nature", emoji: "🌸" },
  { id: 83, english: "Sun", uzbek: "Quyosh", category: "nature", emoji: "☀️" },
  { id: 84, english: "Moon", uzbek: "Oy", category: "nature", emoji: "🌙" },
  { id: 85, english: "Star", uzbek: "Yulduz", category: "nature", emoji: "⭐" },

  // Sport
  { id: 86, english: "Football", uzbek: "Futbol", category: "sports", emoji: "⚽" },
  { id: 87, english: "Basketball", uzbek: "Basketbol", category: "sports", emoji: "🏀" },
  { id: 88, english: "Swimming", uzbek: "Suzish", category: "sports", emoji: "🏊" },
  { id: 89, english: "Running", uzbek: "Yugurish", category: "sports", emoji: "🏃" },
  { id: 90, english: "Tennis", uzbek: "Tennis", category: "sports", emoji: "🎾" },

  // Maktab
  { id: 91, english: "School", uzbek: "Maktab", category: "school", emoji: "🏫" },
  { id: 92, english: "Book", uzbek: "Kitob", category: "school", emoji: "📚" },
  { id: 93, english: "Pen", uzbek: "Qalam", category: "school", emoji: "🖊️" },
  { id: 94, english: "Teacher", uzbek: "O'qituvchi", category: "school", emoji: "👩‍🏫" },
  { id: 95, english: "Student", uzbek: "O'quvchi", category: "school", emoji: "🧑‍🎓" },

  // Kasb-hunar
  { id: 96, english: "Doctor", uzbek: "Shifokor", category: "jobs", emoji: "👨‍⚕️" },
  { id: 97, english: "Engineer", uzbek: "Muhandis", category: "jobs", emoji: "👷" },
  { id: 98, english: "Chef", uzbek: "Oshpaz", category: "jobs", emoji: "👨‍🍳" },
  { id: 99, english: "Artist", uzbek: "Rassom", category: "jobs", emoji: "🎨" },
  { id: 100, english: "Pilot", uzbek: "Uchuvchi", category: "jobs", emoji: "👨‍✈️" },

  // Vaqt
  { id: 101, english: "Day", uzbek: "Kun", category: "time", emoji: "☀️" },
  { id: 102, english: "Night", uzbek: "Tun", category: "time", emoji: "🌙" },
  { id: 103, english: "Morning", uzbek: "Tong", category: "time", emoji: "🌅" },
  { id: 104, english: "Evening", uzbek: "Kechqurun", category: "time", emoji: "🌆" },
  { id: 105, english: "Hour", uzbek: "Soat", category: "time", emoji: "⏰" },

  // Ob-havo
  { id: 106, english: "Sunny", uzbek: "Quyoshli", category: "weather", emoji: "☀️" },
  { id: 107, english: "Rainy", uzbek: "Yomg'irli", category: "weather", emoji: "🌧️" },
  { id: 108, english: "Cloudy", uzbek: "Bulutli", category: "weather", emoji: "☁️" },
  { id: 109, english: "Snowy", uzbek: "Qorli", category: "weather", emoji: "🌨️" },
  { id: 110, english: "Windy", uzbek: "Shamolli", category: "weather", emoji: "🌬️" },
]

export const categories = [
  { id: "animals", name: "Hayvonlar", emoji: "🐾", count: 10 },
  { id: "colors", name: "Ranglar", emoji: "🎨", count: 10 },
  { id: "fruits", name: "Mevalar", emoji: "🍎", count: 10 },
  { id: "numbers", name: "Raqamlar", emoji: "🔢", count: 20 },
  { id: "body", name: "Tana a'zolari", emoji: "👤", count: 10 },
  { id: "clothes", name: "Kiyim-kechak", emoji: "👕", count: 5 },
  { id: "food", name: "Taom", emoji: "🍽️", count: 5 },
  { id: "house", name: "Uy-joy", emoji: "🏠", count: 5 },
  { id: "transport", name: "Transport", emoji: "🚗", count: 5 },
  { id: "nature", name: "Tabiat", emoji: "🌳", count: 5 },
  { id: "sports", name: "Sport", emoji: "⚽", count: 5 },
  { id: "school", name: "Maktab", emoji: "🏫", count: 5 },
  { id: "jobs", name: "Kasb-hunar", emoji: "👨‍💼", count: 5 },
  { id: "time", name: "Vaqt", emoji: "⏰", count: 5 },
  { id: "weather", name: "Ob-havo", emoji: "🌤️", count: 5 },
]
