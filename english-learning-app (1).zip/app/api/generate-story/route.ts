import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    const { character, setting, item, problem } = await req.json()

    if (!character || !setting || !item || !problem) {
      return NextResponse.json({ error: "Barcha maydonlar to'ldirilishi shart." }, { status: 400 })
    }

    const prompt = `
      Quyidagi elementlardan foydalanib, bolalar uchun qisqa, qiziqarli va ijobiy hikoya yozing:
      Bosh qahramon: ${character}
      Joy: ${setting}
      Sehrli buyum: ${item}
      Muammo: ${problem}

      Hikoya 3-5 paragrafdan iborat bo'lsin va ijobiy yakunlansin.
    `

    const { text } = await generateText({
      model: openai("gpt-4o"), // Eng so'nggi OpenAI modelidan foydalanamiz
      prompt: prompt,
      temperature: 0.7, // Ijodkorlik darajasi
    })

    return NextResponse.json({ story: text })
  } catch (error) {
    console.error("Hikoya yaratishda xato:", error)
    return NextResponse.json({ error: "Hikoya yaratishda xato yuz berdi." }, { status: 500 })
  }
}
