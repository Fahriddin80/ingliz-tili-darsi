import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const word = searchParams.get("word")

  if (!word) {
    return NextResponse.json({ error: "Word parameter is required" }, { status: 400 })
  }

  try {
    const response = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`)

    if (!response.ok) {
      // Agar so'z topilmasa yoki boshqa xato bo'lsa
      if (response.status === 404) {
        return NextResponse.json({ error: "Word not found" }, { status: 404 })
      }
      throw new Error(`Dictionary API error: ${response.statusText}`)
    }

    const data = await response.json()
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error fetching from dictionary API:", error)
    return NextResponse.json({ error: "Failed to fetch word data" }, { status: 500 })
  }
}
