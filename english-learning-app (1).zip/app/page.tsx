"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { BookOpen, Play, Trophy, Home, Search, Volume2, XCircle, Sparkles, Loader2 } from "lucide-react"
import { wordsData, categories, type Word } from "../data/words.tsx" // Faqat .tsx fayliga ishora qilindi

type GameMode = "menu" | "flashcards" | "quiz" | "categories" | "dictionary" | "storyGenerator"
type DictionaryEntry = {
  word: string
  phonetic?: string
  phonetics: { text?: string; audio?: string }[]
  meanings: {
    partOfSpeech: string
    definitions: { definition: string; example?: string }[]
    synonyms?: string[]
    antonyms?: string[]
  }[]
}

export default function EnglishLearningApp() {
  const [gameMode, setGameMode] = useState<GameMode>("menu")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")
  const [currentWordIndex, setCurrentWordIndex] = useState(0)
  const [showTranslation, setShowTranslation] = useState(false)
  const [score, setScore] = useState(0)
  const [quizOptions, setQuizOptions] = useState<string[]>([])
  const [selectedAnswer, setSelectedAnswer] = useState<string>("")
  const [searchTerm, setSearchTerm] = useState("")
  const [dictionaryResult, setDictionaryResult] = useState<DictionaryEntry | null>(null)
  const [loadingDictionary, setLoadingDictionary] = useState(false)
  const [dictionaryError, setDictionaryError] = useState<string | null>(null)
  const [character, setCharacter] = useState("")
  const [setting, setSetting] = useState("")
  const [item, setItem] = useState("")
  const [problem, setProblem] = useState("")
  const [story, setStory] = useState("")
  const [loadingStory, setLoadingStory] = useState(false)
  const [storyError, setStoryError] = useState<string | null>(null)

  const filteredWords =
    selectedCategory === "all" ? wordsData : wordsData.filter((word) => word.category === selectedCategory)

  const currentWord = filteredWords[currentWordIndex]

  useEffect(() => {
    // Load progress from localStorage
    const savedProgress = localStorage.getItem("englishLearningProgress")
    if (savedProgress) {
      const progress = JSON.parse(savedProgress)
      // You might want to update UI elements based on this progress
      // For simplicity, we'll just log it for now
      console.log("Loaded progress:", progress)
    }
  }, [])

  const saveProgress = (learnedWordsCount: number, streakDaysCount: number) => {
    const progress = {
      learnedWords: learnedWordsCount,
      streakDays: streakDaysCount,
      lastPlayDate: new Date().toDateString(),
    }
    localStorage.setItem("englishLearningProgress", JSON.stringify(progress))
  }

  const generateQuizOptions = (correctWord: Word) => {
    const wrongOptions = wordsData
      .filter((w) => w.id !== correctWord.id)
      .sort(() => Math.random() - 0.5)
      .slice(0, 3)
      .map((w) => w.uzbek)

    const options = [...wrongOptions, correctWord.uzbek].sort(() => Math.random() - 0.5)
    setQuizOptions(options)
  }

  const startFlashcards = (category: string) => {
    setSelectedCategory(category)
    setCurrentWordIndex(0)
    setShowTranslation(false)
    setGameMode("flashcards")
  }

  const startQuiz = (category: string) => {
    setSelectedCategory(category)
    setCurrentWordIndex(0)
    setScore(0)
    setSelectedAnswer("")
    setGameMode("quiz")
    if (filteredWords.length > 0) {
      generateQuizOptions(filteredWords[0])
    }
  }

  const nextWord = () => {
    if (currentWordIndex < filteredWords.length - 1) {
      setCurrentWordIndex(currentWordIndex + 1)
      setShowTranslation(false)
      if (gameMode === "quiz") {
        generateQuizOptions(filteredWords[currentWordIndex + 1])
        setSelectedAnswer("")
      }
    } else {
      // End of category/all words
      const learnedCount =
        (JSON.parse(localStorage.getItem("englishLearningProgress") || "{}").learnedWords || 0) + filteredWords.length
      saveProgress(learnedCount, 1) // Simple streak for now
      setGameMode("menu")
    }
  }

  const checkAnswer = (answer: string) => {
    setSelectedAnswer(answer)
    if (answer === currentWord.uzbek) {
      setScore(score + 1)
    }
    setTimeout(() => {
      nextWord()
    }, 1500)
  }

  const speakWord = (text: string, lang = "en-US") => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = lang
      utterance.rate = 0.8
      speechSynthesis.speak(utterance)
    }
  }

  const handleSearch = async () => {
    if (!searchTerm.trim()) return

    setLoadingDictionary(true)
    setDictionaryError(null)
    setDictionaryResult(null)

    try {
      const response = await fetch(`/api/dictionary?word=${searchTerm.trim()}`)
      const data = await response.json()

      if (!response.ok) {
        setDictionaryError(data.error || "So'z topilmadi yoki xato yuz berdi.")
        return
      }
      setDictionaryResult(data[0]) // API array qaytaradi, birinchisini olamiz
    } catch (error) {
      console.error("Search error:", error)
      setDictionaryError("So'z ma'lumotlarini olishda xato yuz berdi.")
    } finally {
      setLoadingDictionary(false)
    }
  }

  const getAudioUrl = (phonetics: DictionaryEntry["phonetics"]) => {
    const usAudio = phonetics.find((p) => p.audio && p.audio.includes("-us.mp3"))
    if (usAudio) return usAudio.audio
    const anyAudio = phonetics.find((p) => p.audio)
    return anyAudio ? anyAudio.audio : null
  }

  const handleGenerateStory = async () => {
    setLoadingStory(true)
    setStory("")
    setStoryError(null)

    try {
      const response = await fetch("/api/generate-story", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ character, setting, item, problem }),
      })

      const data = await response.json()

      if (!response.ok) {
        setStoryError(data.error || "Hikoya yaratishda noma'lum xato yuz berdi.")
        return
      }

      setStory(data.story)
    } catch (err) {
      console.error("API chaqiruvida xato:", err)
      setStoryError("Server bilan bog'lanishda xato yuz berdi.")
    } finally {
      setLoadingStory(false)
    }
  }

  if (gameMode === "menu") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">🌟 Ingliz Tilini O'rganamiz! 🌟</h1>
            <p className="text-white/90 text-lg">Bolalar uchun qiziqarli ingliz tili darslari</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Card
              className="hover:shadow-xl transition-shadow cursor-pointer"
              onClick={() => setGameMode("categories")}
            >
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2 text-2xl">
                  <BookOpen className="w-8 h-8 text-blue-500" />
                  Flashcards
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 mb-4">So'zlarni o'rganing va eslab qoling</p>
                <div className="text-4xl mb-2">📚</div>
              </CardContent>
            </Card>

            <Card
              className="hover:shadow-xl transition-shadow cursor-pointer"
              onClick={() => setGameMode("categories")}
            >
              <CardHeader className="text-center">
                <CardTitle className="flex items-center justify-center gap-2 text-2xl">
                  <Trophy className="w-8 h-8 text-yellow-500" />
                  Quiz
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="text-gray-600 mb-4">Bilimingizni sinab ko'ring</p>
                <div className="text-4xl mb-2">🎯</div>
              </CardContent>
            </Card>
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center justify-center gap-2 text-2xl">
                <Search className="w-8 h-8 text-green-500" />
                Lug'at
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-4">Istagan so'zni qidiring va ma'nosini bilib oling</p>
              <Button onClick={() => setGameMode("dictionary")} className="bg-green-500 hover:bg-green-600">
                Lug'atga o'tish
              </Button>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center justify-center gap-2 text-2xl">
                <Sparkles className="w-8 h-8 text-purple-500" />
                Sehrli Hikoya Yaratuvchi
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-4">O'zingizning noyob hikoyangizni yarating!</p>
              <Button onClick={() => setGameMode("storyGenerator")} className="bg-purple-500 hover:bg-purple-600">
                Hikoya Yaratish
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-center">📊 Statistika</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-2xl font-bold text-blue-500">{wordsData.length}</div>
                  <div className="text-sm text-gray-600">Jami so'zlar</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-500">{categories.length}</div>
                  <div className="text-sm text-gray-600">Kategoriyalar</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (gameMode === "categories") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <Button onClick={() => setGameMode("menu")} variant="outline" className="bg-white">
              <Home className="w-4 h-4 mr-2" />
              Bosh sahifa
            </Button>
            <h2 className="text-2xl font-bold text-white">Kategoriyani tanlang</h2>
            <div></div>
          </div>

          <div className="grid md:grid-cols-2 gap-4 mb-6">
            <Card className="hover:shadow-xl transition-shadow cursor-pointer" onClick={() => startFlashcards("all")}>
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-2">🌈</div>
                <h3 className="text-xl font-bold mb-2">Barcha so'zlar</h3>
                <p className="text-gray-600">Flashcards</p>
                <Badge className="mt-2">{wordsData.length} ta so'z</Badge>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-shadow cursor-pointer" onClick={() => startQuiz("all")}>
              <CardContent className="p-6 text-center">
                <div className="text-4xl mb-2">🎯</div>
                <h3 className="text-xl font-bold mb-2">Barcha so'zlar</h3>
                <p className="text-gray-600">Quiz</p>
                <Badge className="mt-2">{wordsData.length} ta so'z</Badge>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {categories.map((category) => (
              <Card key={category.id} className="hover:shadow-xl transition-shadow">
                <CardContent className="p-6 text-center">
                  <div className="text-4xl mb-2">{category.emoji}</div>
                  <h3 className="text-xl font-bold mb-2">{category.name}</h3>
                  <Badge className="mb-4">{wordsData.filter((w) => w.category === category.id).length} ta so'z</Badge>
                  <div className="flex gap-2 justify-center">
                    <Button onClick={() => startFlashcards(category.id)} size="sm">
                      📚 Flashcards
                    </Button>
                    <Button onClick={() => startQuiz(category.id)} size="sm" variant="outline">
                      🎯 Quiz
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    )
  }

  if (gameMode === "flashcards") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-400 via-blue-500 to-purple-600 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <Button onClick={() => setGameMode("categories")} variant="outline" className="bg-white">
              <Home className="w-4 h-4 mr-2" />
              Orqaga
            </Button>
            <Badge className="bg-white text-black">
              {currentWordIndex + 1} / {filteredWords.length}
            </Badge>
          </div>

          <Card className="mb-6 hover:shadow-2xl transition-shadow">
            <CardContent className="p-8 text-center">
              <div className="text-6xl mb-4">{currentWord.emoji}</div>
              <h2 className="text-4xl font-bold mb-4 text-blue-600">{currentWord.english}</h2>
              <Button onClick={() => speakWord(currentWord.english)} className="mb-4" size="sm">
                <Play className="w-4 h-4 mr-2" />
                Tinglash
              </Button>
              {currentWord.pronunciation && (
                <div className="text-sm text-gray-500 mb-4">[{currentWord.pronunciation}]</div>
              )}

              {showTranslation ? (
                <div className="animate-fade-in">
                  <h3 className="text-3xl font-bold text-green-600 mb-4">{currentWord.uzbek}</h3>
                  <Button onClick={nextWord} className="bg-green-500 hover:bg-green-600">
                    {currentWordIndex < filteredWords.length - 1 ? "Keyingi so'z" : "Tugadi"}
                  </Button>
                </div>
              ) : (
                <Button onClick={() => setShowTranslation(true)} className="bg-blue-500 hover:bg-blue-600">
                  Tarjimasini ko'rish
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (gameMode === "quiz") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 p-4">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <Button onClick={() => setGameMode("categories")} variant="outline" className="bg-white">
              <Home className="w-4 h-4 mr-2" />
              Orqaga
            </Button>
            <div className="flex gap-4">
              <Badge className="bg-white text-black">
                {currentWordIndex + 1} / {filteredWords.length}
              </Badge>
              <Badge className="bg-green-500 text-white">Ball: {score}</Badge>
            </div>
          </div>

          <Card className="mb-6">
            <CardContent className="p-8 text-center">
              <div className="text-6xl mb-4">{currentWord.emoji}</div>
              <h2 className="text-3xl font-bold mb-4 text-purple-600">{currentWord.english}</h2>
              <Button onClick={() => speakWord(currentWord.english)} className="mb-6" size="sm">
                <Play className="w-4 h-4 mr-2" />
                Tinglash
              </Button>

              <p className="text-lg mb-6">Bu so'zning ma'nosi nima?</p>

              <div className="grid grid-cols-2 gap-4">
                {quizOptions.map((option, index) => (
                  <Button
                    key={index}
                    onClick={() => checkAnswer(option)}
                    disabled={selectedAnswer !== ""}
                    className={`p-4 text-lg ${
                      selectedAnswer === option
                        ? option === currentWord.uzbek
                          ? "bg-green-500 hover:bg-green-600"
                          : "bg-red-500 hover:bg-red-600"
                        : selectedAnswer !== "" && option === currentWord.uzbek
                          ? "bg-green-500 hover:bg-green-600"
                          : "bg-blue-500 hover:bg-blue-600"
                    }`}
                  >
                    {option}
                  </Button>
                ))}
              </div>

              {selectedAnswer && (
                <div className="mt-4 text-lg font-bold">
                  {selectedAnswer === currentWord.uzbek ? (
                    <span className="text-green-600">✅ To'g'ri!</span>
                  ) : (
                    <span className="text-red-600">❌ Noto'g'ri. To'g'ri javob: {currentWord.uzbek}</span>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (gameMode === "dictionary") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-400 via-indigo-500 to-blue-600 p-4">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <Button onClick={() => setGameMode("menu")} variant="outline" className="bg-white">
              <Home className="w-4 h-4 mr-2" />
              Bosh sahifa
            </Button>
            <h2 className="text-2xl font-bold text-white">Lug'at</h2>
            <div></div>
          </div>

          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex gap-2 mb-4">
                <Input
                  type="text"
                  placeholder="So'z qidiring..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter") handleSearch()
                  }}
                  className="flex-grow"
                />
                <Button onClick={handleSearch} disabled={loadingDictionary}>
                  {loadingDictionary ? "Qidirilmoqda..." : <Search className="w-5 h-5" />}
                </Button>
              </div>

              {dictionaryError && (
                <div className="text-red-600 text-center mb-4 flex items-center justify-center gap-2">
                  <XCircle className="w-5 h-5" /> {dictionaryError}
                </div>
              )}

              {dictionaryResult && (
                <div className="mt-4 p-4 border rounded-lg bg-gray-50 animate-fade-in">
                  <h3 className="text-3xl font-bold text-blue-700 mb-2 flex items-center gap-2">
                    {dictionaryResult.word}
                    {dictionaryResult.phonetics && getAudioUrl(dictionaryResult.phonetics) && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          const audioUrl = getAudioUrl(dictionaryResult.phonetics)
                          if (audioUrl) {
                            new Audio(audioUrl).play()
                          }
                        }}
                      >
                        <Volume2 className="w-6 h-6 text-blue-500" />
                      </Button>
                    )}
                  </h3>
                  {dictionaryResult.phonetic && <p className="text-gray-600 mb-4">[{dictionaryResult.phonetic}]</p>}

                  {dictionaryResult.meanings.map((meaning, index) => (
                    <div key={index} className="mb-4">
                      <h4 className="text-xl font-semibold text-purple-700 mb-2">{meaning.partOfSpeech}</h4>
                      <ul className="list-disc list-inside ml-4">
                        {meaning.definitions.map((def, defIndex) => (
                          <li key={defIndex} className="mb-2">
                            <p className="text-gray-800">{def.definition}</p>
                            {def.example && <p className="text-gray-600 italic text-sm">Misol: "{def.example}"</p>}
                          </li>
                        ))}
                      </ul>
                      {meaning.synonyms && meaning.synonyms.length > 0 && (
                        <p className="text-sm text-gray-700 mt-2">**Sinonimlar:** {meaning.synonyms.join(", ")}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (gameMode === "storyGenerator") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-300 via-pink-300 to-yellow-300 p-4 flex items-center justify-center">
        <div className="max-w-3xl w-full space-y-6">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold text-purple-700 flex items-center justify-center gap-2">
                <Sparkles className="w-8 h-8" />
                Sehrli Hikoya Yaratuvchi
              </CardTitle>
              <p className="text-gray-600">O'zingizning noyob hikoyangizni yarating!</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                placeholder="Bosh qahramon (masalan: Jasur quyoncha)"
                value={character}
                onChange={(e) => setCharacter(e.target.value)}
                className="p-3 text-lg"
              />
              <Input
                placeholder="Joy (masalan: Sirli o'rmon)"
                value={setting}
                onChange={(e) => setSetting(e.target.value)}
                className="p-3 text-lg"
              />
              <Input
                placeholder="Sehrli buyum (masalan: Yorqin tosh)"
                value={item}
                onChange={(e) => setItem(e.target.value)}
                className="p-3 text-lg"
              />
              <Input
                placeholder="Muammo (masalan: Yo'qolgan do'st)"
                value={problem}
                onChange={(e) => setProblem(e.target.value)}
                className="p-3 text-lg"
              />
              <Button
                onClick={handleGenerateStory}
                disabled={loadingStory || !character || !setting || !item || !problem}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white text-lg py-3"
              >
                {loadingStory ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Yaratilmoqda...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-5 w-5" />
                    Hikoya Yaratish
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {storyError && (
            <Card className="bg-red-100 border-red-400 text-red-700 shadow-lg">
              <CardContent className="p-4 text-center">
                <p>{storyError}</p>
              </CardContent>
            </Card>
          )}

          {story && (
            <Card className="shadow-lg animate-fade-in">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl font-bold text-blue-700 flex items-center justify-center gap-2">
                  <BookOpen className="w-6 h-6" />
                  Sizning Hikoyangiz!
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={story}
                  readOnly
                  rows={10}
                  className="w-full p-4 text-lg border-none resize-none bg-gray-50"
                />
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    )
  }

  return null
}
